﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'de', {
	alertUrl: 'Bitte geben Sie die Bild-URL an',
	alt: 'Alternativer Text',
	border: 'Rahmen',
	btnUpload: 'Zum Server senden',
	button2Img: 'Möchten Sie den gewählten Bild-Button in ein einfaches Bild umwandeln?',
	hSpace: 'Horizontal-Abstand',
	img2Button: 'Möchten Sie das gewählten Bild in einen Bild-Button umwandeln?',
	infoTab: 'Bild-Info',
	linkTab: 'Link',
	lockRatio: 'Größenverhältnis beibehalten',
	menu: 'Bild-Eigenschaften',
	resetSize: 'Größe zurücksetzen',
	title: 'Bild-Eigenschaften',
	titleButton: 'Bildbutton-Eigenschaften',
	upload: 'Hochladen',
	urlMissing: 'Imagequelle URL fehlt.',
	vSpace: 'Vertikal-Abstand',
	validateBorder: 'Rahmen muß eine ganze Zahl sein.',
	validateHSpace: 'Horizontal-Abstand muß eine ganze Zahl sein.',
	validateVSpace: 'Vertikal-Abstand muß eine ganze Zahl sein.'
} );
