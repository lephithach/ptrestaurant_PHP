<div id="ajax-cart">
    <?php include 'ajax-cart-content.php'; ?>
</div>